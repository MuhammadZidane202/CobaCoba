@extends('layouts.template')

@section('judul')
Menu
@endsection

<section id="menu" class="menu">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 mt-5">
        <div class="card">
          <div class="card-body">
            <h1 class="card-title text-center">Menu</h1>
            <p>Selamat datang, </p>
            <p>Email: </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
